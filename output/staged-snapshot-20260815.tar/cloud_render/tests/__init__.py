"""Offline cloud-render tests."""
